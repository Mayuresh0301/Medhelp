<?php
$servername="localhost";
$username="root";
$password="";
$database_name="medhelp";

$conn = mysqli_connect($servername,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
if(isset($_POST['save']))
{
    $nam = $_POST['name'];
    $phon = $_POST['phone'];
    $pass = $_POST['password'];
    $pincode = $_POST['apincode'];
    $sql_query = "INSERT INTO signup_details(Nameee,Phone,Passworddd,Pincode) VALUES ('$nam','$phon','$pass','$pincode')";
    if(mysqli_query($conn,$sql_query))
    {
      //  echo "New Details Entry inserted successfully!";
        header("Location: login.html");
    }
    else
    {
        echo "Error: " . $sql . "" . mysqli_error($conn);
    }
    mysqli_close($conn);
}
?>