<?php include "config.php" ?>
<?php
    if (isset($_GET['upd']))
    {
        $Phone = $_GET['upd'];
        $query = "SELECT * FROM signup_details WHERE Phone = $Phone";
        $fire = mysqli_query($con,$query) or die ("can not fetch data from database. ".mysqli_error($con));
        $signup_details = mysqli_fetch_assoc($fire);
        

    }

?>

<!-- Update data -->

<?php
    if(isset($_POST['btnupdate']))
    {   
        
        $Nameee= $_POST['Nameee'];
        $Phone= $_POST['Phone'];
        $Passworddd= $_POST['Passworddd'];
        $Pincode= $_POST['Pincode'];

        $query = "UPDATE signup_details SET Nameee = '$Nameee', Phone= '$Phone', Passworddd = '$Passworddd', Pincode= '$Pincode' WHERE Phone = $Phone ";
        
        $fire = mysqli_query($con,$query) or die("cannot update data. ".mysqli_error($con));

        if ($fire) header ("Location:index.php");

    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" />
    <title>signup_details Data</title>
</head>
<body>


    <div class="container">
    <div class="row">
    <div class="col-lg-12">
    
<!-- signup_details detail form -->
    <div class="col-lg-8 ">
    <h3>Update Details</h3>
    <hr>
    <form name ="empdetail" Phone="emp" action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        <div class ="form-group">
            <label for="Nameee">Nameee</label>
            <input value="<?php echo $signup_details['Nameee']?>" name="Nameee" Phone="Nameee" type="text" class="form-control" placeholder="Nameee" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Phone">LOCATION</label>
            <input value="<?php echo $signup_details['Phone']?>" name="Phone" Phone="Phone" type="text" class="form-control" placeholder="Phone" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Passworddd">DESIGNATION</label>
            <input value="<?php echo $signup_details['Passworddd']?>" name="Passworddd" Phone="Passworddd" type="text" class="form-control" placeholder="Passworddd" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Pincode">CONTACT NO.</label>
            <input value="<?php echo $signup_details['Pincode']?>" name="Pincode" Phone="Pincode" type="text" class="form-control" placeholder="Pincode" >
        </div>
    <br>
        <div class ="form-group">
        <button name="btnupdate" Phone="btnupdate" class="btn btn-primary btn-primary">UPDATE</button>
        </div>
    </form>
    </div>
    </div>
    </div>
    </div>
    
</body>
</html>