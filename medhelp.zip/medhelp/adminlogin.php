<?php

session_start();
$servername="localhost";
$username="root";
$password="";
$database_name="medhelp";

$conn = mysqli_connect($servername,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
/*$admin=$password="";
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $admin = trim($_POST["admin"]);
    $password = trim($_POST["password"]);
    if($admin&&$password){
        $sql = "Select admin,password from signup_details";
        if($stmt = mysqli_prepare($conn,$sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_admin);
            
            // Set parameters
            $param_admin = $admin;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $admin, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            
                            $_SESSION["admin"] = $admin;                            
                            
                            // Redirect user to welcome page
                            header("location: Home.html");
                        }
                        
            
                        mysqli_stmt_close($stmt);
            }  }   }
        }
    }
    mysqli_close($conn);
}
*/

if (isset($_POST['admin'])) {
    $admin = stripslashes($_REQUEST['admin']);    // removes backslashes
    $admin = mysqli_real_escape_string($conn, $admin);
    $password = stripslashes($_REQUEST['password']);
    $password = mysqli_real_escape_string($conn, $password);
    // Check user is exist in the database
    $query    = "SELECT * FROM `admindetail` WHERE admin='$admin'
                 AND password='$password'";
    $result = mysqli_query($conn, $query); //or die(mysql_error());
    $count = mysqli_num_rows($result);
    
    if ($count>0) {
       
        // Redirect to user dashboard page
        header("Location: admin.php");
    } else {
        echo "<div class='form'>
              <h3>Incorrect Username/password.</h3><br/>
              
              </div>";
    }
}



?>

 

  








