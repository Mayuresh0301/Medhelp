<?php include "config.php" ?>

<!-- Insert data  -->
<?php 
    if((isset($_POST['submit'])))
    {   
        
        $Nameee= $_POST['Nameee'];
        $Phone= $_POST['Phone'];
        $Passworddd= $_POST['Passworddd'];
        $Pincode= $_POST['Pincode'];
		

        $query = "INSERT INTO signup_details(Nameee,Phone,Passworddd,Pincode) VALUE('$Nameee','$Phone','$Passworddd','$Pincode')";
        
        $fire = mysqli_query($con,$query) or die("cannot insert data into database. ".mysqli_error($con));

        if ($fire) echo "Data Submitted to Database.";

    
    }
?>    

<!-- Delete data -->
<?php
    if (isset($_GET['del']))
    {
        $Phone = $_GET['del'];
        $query = "DELETE FROM signup_details WHERE Phone = $Phone";
        $fire = mysqli_query($con,$query) or die ("cannot delete data from database. ".mysqli_error($con));
        if ($fire) {
			echo "Data Deleted from Database.";
			
		}
    }


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel = "stylesheet" href = "https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" />
    <title>signup_details data</title>
</head>
<body>


    <div class="container">
    <div class="row">
    <div class="col-lg-8">
    <!-- show data here -->
    <div class="col-lg-8">

    <h7>signup_details data </h7>
    
    <br>
    <table class="table table-striped">
    <thead>
      <tr>
        <th>Nameee</th>
        <th>Phone</th>
        <th>Passworddd</th>
		<th>Pincode</th>
		
		
      </tr>
    </thead>
    <tbody>
    <?php 

        $query = "SELECT * FROM signup_details";
        $fire = mysqli_query($con,$query) or die("can not fetch data from database. ".mysqli_error($con));

        //if ($fire) echo "We got the data from database.";
        if (mysqli_num_rows($fire)>0)
        {

                while($signup_details = mysqli_fetch_assoc($fire)){ ?>
                
                    <tr>

                        <td><?php echo $signup_details['Nameee'] ?> </td>
                        <td><?php echo $signup_details['Phone'] ?> </td>
                        <td><?php echo $signup_details['Passworddd'] ?> </td>
						<td><?php echo $signup_details['Pincode'] ?> </td>
						
                        <td>
                            <a href = "<?php $_SERVER ['PHP_SELF']?>?del=<?php echo $signup_details['Phone']?>" 
                                    
                               class = "btn btn-sm btn-danger">Delete</a>
                        </td>
                        <td>
                           
                        </td>

                        

                    <tr>
                    <?php
                }
            }
        ?>
    </tbody>
    </table>
   

    <hr>
    <h3>userdetail</h3>
    <hr>
    
<!-- Employee detail form -->
    <form name ="empdetail" Phone="emp" action="<?php $_SERVER['PHP_SELF']?>" method="POST">
        <div class ="form-group">
            <label for="Nameee">Name</label>
            <input name="Nameee" Phone="Nameee" type="text" class="form-control" placeholder="Name" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Phone">Phone</label>
            <input name="Phone" Phone="Phone" type="text" class="form-control" placeholder="Phone" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Passworddd">Password</label>
            <input name="Passworddd" Phone="Passworddd" type="text" class="form-control" placeholder="Passworddd" >
        </div>
    <br>
        <div class ="form-group">
            <label for="Pincode">Pincode</label>
            <input name="Pincode" Phone="Pincode" type="text" class="form-control" placeholder="Pincode" >
        </div>
		
    <br>
        <div class ="form-group">
        <button name="submit" Phone="submit" class="btn btn-primary btn-primary">SUBMIT</button>
        </div>
    </form>
    </div>
    </div>
    </div>
    </div>
    <div class ="">
        <button >  <a href='index.html'>LOG OUT</a></button>
        </div>
</body>
</html>