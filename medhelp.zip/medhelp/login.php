<?php

session_start();
$servername="localhost";
$username="root";
$password="";
$database_name="medhelp";

$conn = mysqli_connect($servername,$username,$password,$database_name);
if(!$conn)
{
    die("Connection Failed:" . mysqli_connect_error());
}
/*$Phone=$password="";
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $Phone = trim($_POST["Phone"]);
    $password = trim($_POST["password"]);
    if($Phone&&$password){
        $sql = "Select Phone,password from signup_details";
        if($stmt = mysqli_prepare($conn,$sql)){
            mysqli_stmt_bind_param($stmt, "s", $param_Phone);
            
            // Set parameters
            $param_Phone = $Phone;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $Phone, $hashed_password);
                    if(mysqli_stmt_fetch($stmt)){
                        if(password_verify($password, $hashed_password)){
                            // Password is correct, so start a new session
                            session_start();
                            
                            // Store data in session variables
                            $_SESSION["loggedin"] = true;
                            
                            $_SESSION["Phone"] = $Phone;                            
                            
                            // Redirect user to welcome page
                            header("location: Home.html");
                        }
                        
            
                        mysqli_stmt_close($stmt);
            }  }   }
        }
    }
    mysqli_close($conn);
}
*/

if (isset($_POST['Phone'])) {
    $Phone = stripslashes($_REQUEST['Phone']);    // removes backslashes
    $Phone = mysqli_real_escape_string($conn, $Phone);
    $Passworddd = stripslashes($_REQUEST['password']);
    $Passworddd = mysqli_real_escape_string($conn, $Passworddd);
    // Check user is exist in the database
    $query    = "SELECT * FROM `signup_details` WHERE Phone='$Phone'
                 AND Passworddd='$Passworddd'";
    $result = mysqli_query($conn, $query); //or die(mysql_error());
    $count = mysqli_num_rows($result);
    
    if ($count>0) {
       
        // Redirect to user dashboard page
        header("Location: Home.html");
    } else {
        echo "<div class='form'>
              <h3>Incorrect Username/password.</h3><br/>
              <p class='link'>Click here to <a href='login.html'>Login</a> again.</p>
              </div>";
    }
}



?>
